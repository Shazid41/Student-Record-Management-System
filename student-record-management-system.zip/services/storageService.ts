
import { Student } from '../types';
import * as XLSX from 'xlsx';

const STORAGE_KEY = 'student_record_mgmt_db';

export const storageService = {
  getStudents: (): Student[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveStudents: (students: Student[]): void => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
  },

  addStudent: (student: Student): void => {
    const students = storageService.getStudents();
    students.push(student);
    storageService.saveStudents(students);
  },

  updateStudent: (updatedStudent: Student): void => {
    const students = storageService.getStudents();
    const index = students.findIndex(s => s.id === updatedStudent.id);
    if (index !== -1) {
      students[index] = updatedStudent;
      storageService.saveStudents(students);
    }
  },

  deleteStudent: (id: string): void => {
    const students = storageService.getStudents();
    const filtered = students.filter(s => s.id !== id);
    storageService.saveStudents(filtered);
  },

  exportData: () => {
    const students = storageService.getStudents();
    
    // Transform data for Excel (human readable headers)
    const excelData = students.map(s => ({
      'Roll Number': s.rollNumber,
      'Full Name': s.name,
      'GPA': s.gpa,
      'Department': s.department,
      'Email': s.email,
      'ID': s.id, // Keep hidden-ish for re-importing consistency
      'Enrollment Date': s.enrollmentDate
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students");

    // Generate buffer and trigger download
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `StudentRecords_${new Date().toISOString().split('T')[0]}.xlsx`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  importData: (file: File): Promise<Student[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];

          // Map back to Student interface
          const students: Student[] = jsonData.map(item => ({
            rollNumber: String(item['Roll Number'] || ''),
            name: String(item['Full Name'] || ''),
            gpa: Number(item['GPA'] || 0),
            department: String(item['Department'] || ''),
            email: String(item['Email'] || ''),
            id: String(item['ID'] || crypto.randomUUID()),
            enrollmentDate: String(item['Enrollment Date'] || new Date().toISOString())
          }));

          storageService.saveStudents(students);
          resolve(students);
        } catch (err) {
          reject('Invalid Excel file format.');
        }
      };
      reader.onerror = () => reject('File reading error.');
      reader.readAsArrayBuffer(file);
    });
  }
};
